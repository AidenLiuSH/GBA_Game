/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=10x10 alien images/alien.png 
 * Time-stamp: Thursday 11/11/2021, 19:47:51
 * 
 * Image Information
 * -----------------
 * images/alien.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ALIEN_H
#define ALIEN_H

extern const unsigned short alien[100];
#define ALIEN_SIZE 200
#define ALIEN_LENGTH 100
#define ALIEN_WIDTH 10
#define ALIEN_HEIGHT 10

#endif

