/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=6x6 rescue images/rescue.png 
 * Time-stamp: Thursday 11/11/2021, 19:54:52
 * 
 * Image Information
 * -----------------
 * images/rescue.png 6@6
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RESCUE_H
#define RESCUE_H

extern const unsigned short rescue[36];
#define RESCUE_SIZE 72
#define RESCUE_LENGTH 36
#define RESCUE_WIDTH 6
#define RESCUE_HEIGHT 6

#endif

